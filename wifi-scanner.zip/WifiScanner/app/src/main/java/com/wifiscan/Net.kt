package com.wifiscan

import android.content.Context
import android.net.ConnectivityManager
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.net.*

data class Device(val ip: String, val host: String, val mac: String, val type: String, val ports: List<Int>, val me: Boolean)

val PORTS = mapOf(
    21 to "FTP", 22 to "SSH", 23 to "Telnet", 53 to "DNS", 80 to "HTTP", 135 to "RPC", 139 to "NetBIOS",
    443 to "HTTPS", 445 to "SMB", 515 to "LPD", 554 to "RTSP", 631 to "IPP", 1883 to "MQTT", 3389 to "RDP",
    5900 to "VNC", 7000 to "AirPlay", 8000 to "HTTP-alt", 8008 to "Chromecast", 8009 to "Chromecast",
    8080 to "HTTP-proxy", 8443 to "HTTPS-alt", 9100 to "Printer", 37777 to "DVR", 62078 to "iPhone-sync"
)

object Net {
    fun info(ctx: Context): Pair<String?, String?> {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val lp = cm.getLinkProperties(cm.activeNetwork) ?: return Pair(null, null)
        val ip = lp.linkAddresses.firstOrNull { it.address is Inet4Address }?.address?.hostAddress
        val gw = lp.routes.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress
        return Pair(ip, gw)
    }

    fun arp(): Map<String, String> = runCatching {
        File("/proc/net/arp").readLines().drop(1).mapNotNull {
            val p = it.trim().split(Regex("\\s+"))
            if (p.size >= 4 && p[3] != "00:00:00:00:00:00") p[0] to p[3] else null
        }.toMap()
    }.getOrDefault(emptyMap())

    fun open(ip: String, port: Int, timeout: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(ip, port), timeout); true }
    } catch (e: Exception) { false }

    suspend fun scanPorts(ip: String, ports: Collection<Int> = PORTS.keys): List<Int> = coroutineScope {
        ports.map { p -> async(Dispatchers.IO) { if (open(ip, p, 300)) p else null } }.awaitAll().filterNotNull().sorted()
    }

    fun classify(ip: String, gw: String?, host: String, ports: List<Int>, me: Boolean): String {
        val h = host.lowercase()
        return when {
            me -> "Telefon (bu cihaz)"
            ip == gw -> "Router"
            ports.any { it in listOf(554, 37777) } || listOf("cam", "ipc", "hikvision", "dahua").any { h.contains(it) } -> "Kamera"
            62078 in ports || listOf("iphone", "ipad", "android", "galaxy", "redmi", "xiaomi", "huawei", "oppo", "pixel").any { h.contains(it) } -> "Telefon"
            ports.any { it in listOf(9100, 631, 515) } -> "Printer"
            ports.any { it in listOf(8008, 8009, 7000) } || listOf("tv", "roku", "chromecast").any { h.contains(it) } -> "TV / Media"
            ports.any { it in listOf(3389, 445, 135, 139, 22, 5900) } || listOf("pc", "laptop", "desktop", "notebook", "macbook").any { h.contains(it) } -> "Notebook / PC"
            else -> "Digər"
        }
    }

    suspend fun scan(ctx: Context, progress: (Int) -> Unit): List<Device> = coroutineScope {
        val (me, gw) = info(ctx)
        if (me == null) return@coroutineScope emptyList()
        val prefix = me.substringBeforeLast('.') + "."
        val sem = Semaphore(24)
        var done = 0
        val probes = (1..254).map { i ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    val ip = prefix + i
                    val ports = scanPorts(ip)
                    val reach = ports.isNotEmpty() || runCatching { InetAddress.getByName(ip).isReachable(300) }.getOrDefault(false)
                    synchronized(this@Net) { done++; progress(done * 100 / 254) }
                    Triple(ip, ports, reach)
                }
            }
        }.awaitAll()
        val arp = arp()
        probes.filter { it.third || it.first in arp || it.first == me }.map { (ip, ports, _) ->
            async(Dispatchers.IO) {
                val host = withTimeoutOrNull(2000) { runCatching { InetAddress.getByName(ip).canonicalHostName }.getOrDefault(ip) } ?: ip
                Device(ip, if (host == ip) "-" else host, arp[ip] ?: "-", classify(ip, gw, host, ports, ip == me), ports, ip == me)
            }
        }.awaitAll()
    }

    fun run(cmd: List<String>, onLine: (String) -> Unit) {
        runCatching {
            val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
            p.inputStream.bufferedReader().forEachLine(onLine)
            p.waitFor()
        }.onFailure { onLine("Xəta: ${it.message}") }
    }

    fun ping(host: String, onLine: (String) -> Unit) = run(listOf("ping", "-c", "4", "-W", "2", host), onLine)

    fun trace(host: String, onLine: (String) -> Unit) {
        for (ttl in 1..20) {
            var hop = "*"; var time = ""; var reached = false
            run(listOf("ping", "-c", "1", "-t", ttl.toString(), "-W", "2", host)) { l ->
                Regex("[Ff]rom ([0-9.]+)").find(l)?.let { hop = it.groupValues[1] }
                Regex("time=([0-9.]+)").find(l)?.let { time = " ${it.groupValues[1]} ms" }
                if (l.contains("bytes from")) reached = true
            }
            onLine("$ttl  $hop$time")
            if (reached) break
        }
    }

    fun download(): Double {
        val t0 = System.nanoTime(); var n = 0L
        val c = URL("https://speed.cloudflare.com/__down?bytes=25000000").openConnection() as HttpURLConnection
        c.connectTimeout = 5000; c.readTimeout = 10000
        val b = ByteArray(65536)
        c.inputStream.use { s ->
            while (true) {
                val r = s.read(b); if (r < 0) break
                n += r
                if (System.nanoTime() - t0 > 10e9) break
            }
        }
        return n * 8 / ((System.nanoTime() - t0) / 1e9) / 1e6
    }

    fun upload(): Double {
        val size = 10_000_000
        val c = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 5000; c.readTimeout = 15000
        c.setFixedLengthStreamingMode(size)
        val t0 = System.nanoTime()
        val chunk = ByteArray(65536)
        c.outputStream.use { o -> var sent = 0; while (sent < size) { val k = minOf(chunk.size, size - sent); o.write(chunk, 0, k); sent += k } }
        c.responseCode
        return size * 8 / ((System.nanoTime() - t0) / 1e9) / 1e6
    }
}
