package com.wifiscan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

val ORDER = listOf("Router", "Kamera", "Notebook / PC", "Telefon (bu cihaz)", "Telefon", "TV / Media", "Printer", "Digər")

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    var target by remember { mutableStateOf("") }
    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("📡") }, label = { Text("Cihazlar") })
            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("🛠") }, label = { Text("Alətlər") })
        }
    }) { pad ->
        Box(Modifier.padding(pad).statusBarsPadding()) {
            if (tab == 0) Devices { target = it; tab = 1 } else Tools(target) { target = it }
        }
    }
}

@Composable
fun Devices(onTool: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<Device>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var pct by remember { mutableIntStateOf(0) }
    Column(Modifier.padding(12.dp)) {
        Button(onClick = {
            if (!busy) scope.launch {
                busy = true; pct = 0
                list = Net.scan(ctx) { pct = it }
                busy = false
            }
        }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Skan edilir... $pct%" else "Şəbəkəni skan et") }
        if (busy) LinearProgressIndicator(progress = { pct / 100f }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
        val groups = list.groupBy { it.type }
        LazyColumn(Modifier.padding(top = 8.dp)) {
            ORDER.filter { it in groups }.forEach { type ->
                val devs = groups[type]!!.sortedBy { it.ip.substringAfterLast('.').toInt() }
                item { Text("$type (${devs.size})", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) }
                items(devs) { d ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(d.ip, style = MaterialTheme.typography.titleSmall)
                            Text("Ad: ${d.host}")
                            Text("MAC: ${d.mac}")
                            Text("Açıq portlar: " + if (d.ports.isEmpty()) "yoxdur" else d.ports.joinToString { "$it ${PORTS[it] ?: ""}" })
                            TextButton(onClick = { onTool(d.ip) }) { Text("Ping / Traceroute") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Tools(target: String, onTarget: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var log by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    fun go(block: () -> Unit) {
        if (busy) return
        busy = true; log = ""
        scope.launch(Dispatchers.IO) { runCatching(block).onFailure { log += "Xəta: ${it.message}\n" }; busy = false }
    }
    Column(Modifier.padding(12.dp)) {
        OutlinedTextField(value = target, onValueChange = onTarget, label = { Text("IP / host (məs. 192.168.1.1 və ya google.com)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy && target.isNotBlank(), onClick = { go { Net.ping(target.trim()) { log += it + "\n" } } }) { Text("Ping") }
            Button(enabled = !busy && target.isNotBlank(), onClick = { go { Net.trace(target.trim()) { log += it + "\n" } } }) { Text("Trace") }
            Button(enabled = !busy, onClick = { go {
                log += "Download test...\n"
                log += "Download: %.1f Mbps\n".format(Net.download())
                log += "Upload test...\n"
                log += "Upload: %.1f Mbps\n".format(Net.upload())
            } }) { Text("Sürət") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Column(Modifier.verticalScroll(rememberScrollState())) { Text(log, style = MaterialTheme.typography.bodySmall) }
    }
}
